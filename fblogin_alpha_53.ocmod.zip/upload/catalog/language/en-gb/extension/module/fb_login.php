<?php
$_['error_access'] =' Warning there was an access error';
$_['error_login'] = 'This user managed an access via email and password or the password was recovered, connected the login with the email and password';
$_['error_register'] = 'Error registering in the shop or register manually';
$_['insert_email'] = 'Enter your email here';
$_['exemple_email'] = 'example@example.com';
$_['insert_fname'] = 'Insert your name';
$_['insert_lname'] = 'Insert your surname';
$_['title_access_facebook'] = 'Access to Facebook';
$_['loading_facebook'] = 'Loading Facebook login...';