<?php
$_['heading_title'] = 'Facebook Login';
$_['text_edit'] = 'Modifica il modulo Facebook Login';
$_['error_permission'] = 'Attenzione: Non hai i permessi per modificare questo modulo';
$_['error_app_id'] = 'Attenzione: Non hai inserito l\'Id app (lo trovai al link: https://developers.facebook.com)';
$_['entry_name'] = 'Nome modulo';
$_['entry_app_id'] = 'Id app facebook dev';
$_['entry_loc'] = 'Tag lingua (es. en_EN)';
$_['entry_status'] = 'Stato modulo';
$_['entry_type_attach'] = 'Via layout o via id';
$_['text_extension'] = 'Moduli';
$_['text_id'] = 'Con riferimento Id';
$_['text_layout'] = 'Con Layout di Opencart';
$_['text_success'] = 'Modulo login facebook aggiornato con successo';