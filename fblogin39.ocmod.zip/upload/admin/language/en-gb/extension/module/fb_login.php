<?php
$_['heading_title'] = 'Facebook Login';
$_['text_edit'] = 'Edit Module Facebook Login';
$_['entry_app_id'] = 'ID APP Facebook Dev';
$_['entry_app_loc'] = 'Language tag (en_GB)';
$_['entry_status'] = 'Status module';
$_['text_enabled'] = 'Enable';
$_['text_disabled'] = 'Disable';
$_['error_permission'] = 'Warning: You do not have permission to modify Facebook Login module!';
$_['error_app_id'] = 'Warning: You have not entered the id fb app';
$_['error_loc'] = 'Warning: You have not entered the language tag';
