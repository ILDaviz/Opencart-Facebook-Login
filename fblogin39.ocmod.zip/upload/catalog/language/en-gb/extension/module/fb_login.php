<?php
$_['error_email'] = 'Error no email get from Facebook';
$_['error_fname'] = 'Error no first name get from Facebook';
$_['error_lname'] = 'Error no last name get from Facebook';
$_['error_fb_id'] = 'Error no id user get from Facebook';
$_['error_register'] = 'Error register user';
$_['error_login'] = 'Error the default password has been changed, access with email and password';
$_['error_email_noset'] = 'Error no present email Facebook';
$_['text_facebook']     = 'Register or sign in with Facebook';
$_['text_info_login']   = 'Register an account or sign in with your Facebook profile data. We safeguard your information and will NEVER disclose your data.';