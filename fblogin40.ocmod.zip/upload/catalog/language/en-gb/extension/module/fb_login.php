<?php
$_['error_email'] = 'Error no email get from Facebook';
$_['error_fname'] = 'Error no first name get from Facebook';
$_['error_lname'] = 'Error no last name get from Facebook';
$_['error_fb_id'] = 'Error no id user get from Facebook';
$_['entry_email'] = 'Write the e-mail manually and click on the Facebook button.';
$_['error_register'] = 'Error register user';
$_['error_login'] = 'Error the default password has been changed, access with email and password';
$_['error_email_noset'] = 'Error no present email on Facebook';
$_['entry_email_txt'] = 'email';
$_['text_facebook']     = 'Register or sign in with Facebook';
$_['text_info_login']   = 'Register an account or sign in with your Facebook profile data. We safeguard your information and will NEVER disclose your data.';
$_['error_email_not_present']   = 'Errore: no present email';
$_['error_email']   =  'Errore: the email is incorrect';
$_['login_info_popup'] = 'Login Facebook works fine if pop-up is enable in this page.';