<?php
$_['heading_title'] = 'Facebook Login';
$_['text_edit'] = 'Modifica il modulo Facebook Login';
$_['entry_app_id'] = 'ID APP Facebook Dev';
$_['entry_app_loc'] = 'Tag lingua (it_IT)';
$_['entry_status'] = 'Stato modulo';
$_['text_enabled'] = 'Attivo';
$_['text_disabled'] = 'Disattivato';
$_['error_permission'] = 'Attenzione: Non hai i permessi per modificare questo modulo';
$_['error_app_id'] = 'Attenzione: Non hai inserito l\'Id app (lo trovai al link: https://developers.facebook.com)';
$_['error_loc'] = 'Attenzione: Non hai inserito la località';
