<?php
$_['error_email'] = 'Attenzione ricevuta nessuna email da Facebook';
$_['error_fname'] = 'Attenzione ricevuto nessun nome da Facebook';
$_['error_lname'] = 'Attenzione ricevuto nessun cognome da Facebook';
$_['error_fb_id'] = 'Attenzione ricevuto nessun id da Facebook';
$_['entry_email'] = 'Inserisci l\'email manualmente, Facebook non ha fornito l\'email e riclicca sul pulsante di Facebook.';
$_['entry_email_txt'] = 'email';
$_['error_register'] = 'Errore: Di registrazione contatta Acquavivastore o registrati manualmente';
$_['error_login'] = 'Errore: La password di loggin predefinita è stata modificata, accedi con email e password';
$_['error_email_noset'] = 'Errore: Il tuo indirizzo email non è pubblico su Facebook. Modifica le impostazioni per accedere';
$_['text_facebook']     = 'Registrati o accedi con Facebook';
$_['text_info_login']   = 'Registra un account o accedi con i dati del tuo profilo Facebook. Custodiamo le tue informazioni e non diffonderemo MAI i tuoi dati.';
$_['error_email_not_present']   = 'Errore: L\'email non è presente';
$_['error_email']   =  'Errore: L\'email non è corretta!';
$_['login_info_popup'] = 'Il login con Facebook funziona correttamente se i pop-up sono abilitati in questa pagina';