<?php
$_['heading_title'] = 'Facebook Login';
$_['text_edit'] = 'Edit Module Facebook Login';
$_['error_permission'] = 'Warning: You do not have permission to modify Facebook Login module!';
$_['error_app_id'] = 'Warning: You have not entered the id fb app';
$_['entry_name'] = 'Name';
$_['entry_app_id'] = 'Id app facebook dev';
$_['entry_loc'] = 'Language tag (es. en_EN)';
$_['entry_status'] = 'State module';
$_['entry_type_attach'] = 'Layout or specific id';
$_['text_extension'] = 'Module';
$_['text_id'] = 'Id class';
$_['text_layout'] = 'Layout of Opencart';