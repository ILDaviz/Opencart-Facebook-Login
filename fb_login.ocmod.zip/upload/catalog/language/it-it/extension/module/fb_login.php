<?php
$_['error_access'] = 'Attenzione c\'è stato un errore di accesso';
$_['error_login'] = 'Questo utente ha effettuato un accesso mediante email e password o la password è stata recuperata, effettua il login con l\'email e la password';
$_['error_register'] = 'Errore di registrazione contatta il negozioante o registrati manualmente';
$_['insert_email'] = 'Inserisci qui l\'email';
$_['exemple_email'] = 'esempio@esempio.com';
$_['insert_fname'] = 'Inserisci il tuo nome';
$_['insert_lname'] = 'Inserisci il tuo cognome';
$_['title_access_facebook'] = 'Accedi con Facebook';
$_['loading_facebook'] = 'Facebook login in caricamento...';